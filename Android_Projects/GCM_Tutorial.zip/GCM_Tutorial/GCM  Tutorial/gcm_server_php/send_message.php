<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
if (isset($_POST["row_num"]) && isset($_POST["col_num"])&& isset($_POST["data"])) {
    $row_num = $_POST["row_num"];
    $col_num = $_POST["col_num"];
	   $data = $_POST["data"];
    $op=$row_num. ",". $col_num . ",". $data;
	
    include_once './GCM.php';
    
    $gcm = new GCM();

	  include_once 'db_functions.php';
        $db = new DB_Functions();
        $users = $db->getAllUsers();
        if ($users != false)
            $no_of_users = mysql_num_rows($users);
        else
            $no_of_users = 0;
			
			 if ($no_of_users > 0) {
			 
			 
			  while ($row = mysql_fetch_array($users)) {
			   
			  
			  $registatoin_ids = array($row["gcm_regid"]);
    $message = array("price" => $op);

    $result = $gcm->send_notification($registatoin_ids, $message);

    echo $result;
			  
			  }
			 }
}
else
{
echo "Incorrect Input";
}
?>
