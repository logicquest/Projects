<?php
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "gcm");

/*
 * Google API Key
 */
define("GOOGLE_API_KEY", "AIzaSyAivciFJHBpKg5Yl8lrhE9-hl9ilodVL3Q"); // Place your Google API Key
?>