/** Automatically generated file. DO NOT MODIFY */
package cz.romario.opensudoku;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}